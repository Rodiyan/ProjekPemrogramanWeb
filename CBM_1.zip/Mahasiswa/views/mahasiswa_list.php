<!DOCTYPE html>
<html>
<head>
    <title>Daftar Mahasiswa</title>
    <link rel="stylesheet" href="views/style.css">
</head>
<body>
    <div class="container">
        <h2>Daftar Mahasiswa</h2>
        <a href="index.php?action=create" class="add-link">+ Tambah Mahasiswa</a>
        <table>
            <tr>
                <th>No</th>
                <th>ID</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Jurusan</th>
                <th>Aksi</th>
            </tr>
            <?php 
            $no = 1;
            while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['id']; ?></td>
                <td><?= $row['nim']; ?></td>
                <td><?= $row['nama']; ?></td>
                <td><?= $row['jurusan']; ?></td>
                <td class="action-links">
                    <a href="index.php?action=edit&id=<?= $row['id']; ?>">Edit</a> |
                    <a href="index.php?action=delete&id=<?= $row['id']; ?>" 
                       onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>