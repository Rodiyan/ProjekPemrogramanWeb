<!DOCTYPE html>
<html>
<head>
    <title>Edit Mahasiswa</title>
    <link rel="stylesheet" href="views/style.css">
</head>
<body>
    <div class="container">
        <h2>Edit Mahasiswa</h2>
        <form method="POST">
            NIM: <input type="text" name="nim" value="<?= htmlspecialchars($data['nim']); ?>" required><br><br>
            Nama: <input type="text" name="nama" value="<?= htmlspecialchars($data['nama']); ?>" required><br><br>
            Jurusan: <input type="text" name="jurusan" value="<?= htmlspecialchars($data['jurusan']); ?>" required><br><br>
            <button type="submit">Update</button>
        </form>
        <a href="index.php" class="back-link">Kembali</a>
    </div>
</body>
</html>