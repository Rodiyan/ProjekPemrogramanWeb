<!DOCTYPE html>
<html>
<head>
    <title>Tambah Mahasiswa</title>
    <link rel="stylesheet" href="views/style.css">
</head>
<body>
    <div class="container">
        <h2>Tambah Mahasiswa</h2>
        <form method="POST">
            NIM: <input type="text" name="nim" required><br><br>
            Nama: <input type="text" name="nama" required><br><br>
            Jurusan: <input type="text" name="jurusan" required><br><br>
            <button type="submit">Simpan</button>
        </form>
        <a href="index.php" class="back-link">Kembali</a>
    </div>
</body>
</html>