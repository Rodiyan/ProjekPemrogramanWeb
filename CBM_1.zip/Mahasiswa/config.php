<?php
// Kelas untuk mengatur koneksi ke database
class DatabaseConnection {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "db_mahasiswa";
    public $connection;
    public function __construct() {
     // Membuat koneksi ke database
    $this->connection = new mysqli($this->host, $this->username, $this->password, $this->database);

     // Cek jika koneksi gagal
     if ($this->connection->connect_error) {
    die("Koneksi gagal: " . $this->connection->connect_error);
  }
 }
}
// Inisialisasi koneksi database
$db = new DatabaseConnection();
$conn = $db->connection;
?>
