<?php
require_once __DIR__ . '/../config.php'; // karena config.php ada di root, naik 1 folder

class Mahasiswa {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    // ambil semua mahasiswa
    public function getAll() {
        $result = $this->conn->query("SELECT * FROM mahasiswa");
        return $result;
    }

    // tambah mahasiswa
    public function create($nim, $nama, $jurusan) {
        $sql = "INSERT INTO mahasiswa (nim, nama, jurusan) VALUES ('$nim', '$nama', '$jurusan')";
        $result = $this->conn->query($sql);

        if ($result) {
            // reset auto increment agar konsisten
            $this->conn->query("ALTER TABLE mahasiswa AUTO_INCREMENT = 1");
        }

        return $result;
    }

    // ambil mahasiswa berdasarkan id
    public function getById($id) {
        $sql = "SELECT * FROM mahasiswa WHERE id=$id";
        $result = $this->conn->query($sql);
        return $result->fetch_assoc();
    }

    // update mahasiswa
    public function update($id, $nim, $nama, $jurusan) {
        $sql = "UPDATE mahasiswa SET nim='$nim', nama='$nama', jurusan='$jurusan' WHERE id=$id";
        return $this->conn->query($sql);
    }

    // hapus mahasiswa + reset ID
    public function delete($id) {
        $sql = "DELETE FROM mahasiswa WHERE id=$id";
        $result = $this->conn->query($sql);

        if ($result) {
            // reset urutan id agar mulai dari 1
            $this->conn->query("SET @num := 0");
            $this->conn->query("UPDATE mahasiswa SET id = @num := @num + 1");
            $this->conn->query("ALTER TABLE mahasiswa AUTO_INCREMENT = 1");
        }

        return $result;
    }
}
?>
